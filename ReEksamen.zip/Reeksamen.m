%% Opgave 1
clc; clear; close;
p=(72*39)/(72*39+41*61)
%% Opgave 2
clc; clear; close;
syms x
f(x)=(abs(x)+1)/11
E=symsum(x*f(x),x,-2,2)
symsum(x^2*f(x),x,-2,2)-E^2
28/11
%% Opgave 3
clc; clear; close;
n=12
p=4/5
binopdf(0,n,p)+binopdf(1,n,p)+binopdf(2,n,p)+binopdf(3,n,p)+binopdf(4,n,p)+binopdf(5,n,p)+binopdf(6,n,p)+binopdf(7,n,p)+binopdf(8,n,p)+binopdf(9,n,p)+binopdf(10,n,p)
%% Opgave 4
clc; clear; close;
mu=-4
sigma=4
1-normcdf(0,mu,sigma)
%% Opgave 5
clc; clear; close;
syms x
f(x)=(3*x^2)/2
E=int(x*f(x),-1,1)
int(x^2*f(x),-1,1)-E^2
%% Opgave 6
clc; clear; close;
chi2inv(1-0.01,8)
%% Opgave 7
clc; clear; close;
syms x
f(x)=(3/8)*(1+x^2);
int(f(x),-1,x)
%% Opgave 8
clc; clear; close;
syms x y
f(x,y)=9/4*x^2*y^2;
int(int(f(x,y),0.5,1),-1,1)
%% Opgave 9
clc; clear; close;
f=@(y)(1/2).^y*(1/2)^2*(1/(1-0.5));
f(0:3)
f=@(y) ((1/2).^(y));
f(0:3)
f=@(y) (1/2)*(1/2).^y;
f(0:3)
%% Opgave 10
clc; clear; close;
a=[-4 0 3 -1 -1]
var(a)
%% Opgave 11
clc; clear; close;
x=[9 4 6 2]
y=[-3 4 0 5]
cov(x,y)
%% Opgave 12
clc; clear; close;
syms x a
f(x)=(a^x*exp(-a))/factorial(x)
mle(f(x))
%% Opgave 13
clc; clear; close;
Data=[4 7 5 4 8 7 6];
m=mean(Data)
n=6;
sigma=sqrt(var(Data))
[h,p,ci,stats] = ttest(Data,m,'Alpha',0.1)

%% Opgave 14
clc; clear; close;
Data=[4 7 5 4 8 7 6];
mu=mean(Data)
[h,p,ci,stats]=vartest(Data,mu)
%% Opgave 15
clc; clear; close;
Data=[4 7 5 4 8 7 6];
[h,p,ci,stats] = ttest(Data,7)
%% Opgave 16
clc; clear; close;
Data=[4 7 5 4 8 7 6];
[h,p,ci,stats] = ttest(Data,7)
%% Opgave 17
clc; clear; close;
Data=[4 7 5 4 8 7 6];
[h,p,ci,stats] = vartest(Data,2)
%% Opgave 18
clc; clear; close;
X=[-4 -9 -8 -4 -7 -5]
Y= [101 108 103 103 107]
[h, p, ci, stats]=ttest2(X,Y)
2.5393^2
%% Opgave 19
clc; clear; close;
X= [15 10 13 16 14];
Y= [11 9 11 12 10];

n=length(X)
D_bar=mean(X)-mean(Y)
sd=std(X-Y)
T_O_paired=(D_bar-1)/(sd/sqrt(n))
pval=2*(1-tcdf(abs(T_O_paired),n-1))

%%
clc; clear; close;
X= [15 10 13 16 14];
Y= [11 9 11 12 10];
n=length(X)
s1=std(X)
s2=std(Y)
sp=((n-1)*s1^2+(n-1)*s2^2)/(n+n-2)
x_bar1=mean(X)
x_bar2=mean(Y)
t_o=(x_bar1-x_bar2-1)/(sp*sqrt((1/n)+(1/n)))
pval=2*(1-tcdf(abs(t_o),n+n-2))
%%
X= [15 10 13 16 14];
Y= [11 9 11 12 10];
n1=5;
n2=5;
s1=std(X)
s2=std(Y)
x1=mean(X)
x2=mean(Y)
sp=sqrt(((n1-1)*s1^2+(n2-1)*s2^2)/(n1+n2-1))
t_o=(x1-x2-1)/(sp*(sqrt((1/n1)+(1/n2))))
2*(1-tcdf(abs(t_o),n1+n2-2))
%% Opgave 20
clc; clear; close;
X=[-3 -2 -1 -1 0 1 1 3];
Y=[0 -1 0 1 0 1 2 2];

fitlm(X,Y)
%% Opgave 21
clc; clear; close;
X=[-3 -2 -1 -1 0 1 1 3];
Y=[0 -1 0 1 0 1 2 2];

fitlm(X,Y)
%% Opgave 22
clc; clear; close;
X=[-3 -2 -1 -1 0 1 1 3];
Y=[0 -1 0 1 0 1 2 2];

lm=fitlm(X,Y)

coefCI(lm)
%% Opgave 23
clc; clear; close;
data1=[ 15 17 14 17]'
data2=[16 18 17 14]'
data3=[15 11 10 13]'
data= [data1 data2 data3]
anova1(data) % 2.67 F-stat
%% Opgave 24
clc; clear; close;
data1=[ 15 17 14 17]'
data2=[16 18 17 14]'
data3=[15 11 10 13]'
data= [data1 data2 data3]
anova1(data) % 2.67 F-stat
%% Opgave 25
clc; clear; close;
data=[10 8 13 4 5 2 15 15 20
    16 15 16 8 6 5 15 16 13]'
p=anova2(data,3)
